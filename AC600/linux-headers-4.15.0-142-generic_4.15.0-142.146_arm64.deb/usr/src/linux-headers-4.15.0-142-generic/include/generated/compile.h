/* This file is auto generated, version 146-Ubuntu */
/* SMP */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#146-Ubuntu SMP Tue Apr 13 01:08:49 UTC 2021"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "bos02-arm64-057"
#define LINUX_COMPILER "gcc version 7.5.0 (Ubuntu/Linaro 7.5.0-3ubuntu1~18.04)"
